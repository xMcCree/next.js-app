(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_727141ce._.js",
  "static/chunks/f07ee_next_dist_compiled_072afd38._.js",
  "static/chunks/f07ee_next_dist_client_5cf5dcf9._.js",
  "static/chunks/f07ee_next_dist_eb86032f._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
