__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root-of-the-server]__3eaa2cc8._.js",
  "static/chunks/a14e7_react-dom_638ad3bb._.js",
  "static/chunks/node_modules__pnpm_51c25b77._.js",
  "static/chunks/[root-of-the-server]__923cb372._.js",
  "static/chunks/pages__error_5771e187._.js",
  "static/chunks/pages__error_4363c9f7._.js"
])
