globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/f07ee_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_727141ce._.js",
    "static/chunks/f07ee_next_dist_compiled_072afd38._.js",
    "static/chunks/f07ee_next_dist_client_5cf5dcf9._.js",
    "static/chunks/f07ee_next_dist_eb86032f._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_42fd111b._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];