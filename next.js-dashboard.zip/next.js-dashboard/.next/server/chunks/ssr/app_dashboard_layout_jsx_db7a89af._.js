module.exports = {

"[project]/app/dashboard/layout.jsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=app_dashboard_layout_jsx_db7a89af._.js.map